"""
schema_glossary.py

The single source of truth the LLM is grounded on for stages 3 and 4,
and that the validator in stage 5 checks generated SQL against.

IMPORTANT: the formulas in METRICS_GLOSSARY for revenue, orders, AOV,
discount usage, high-value share, sessions and bounce rate are copied from
the exact SQL in dashboard/data_access.py's get_overview_metrics(). If a
formula changes there, mirror the change here. The remaining entries
(customer, geo and campaign metrics) are not on the dashboard overview; their
formulas are plain AVG/SUM over the column and were checked against the data.

Facts stated below that were verified against ecommerce.db (re-check them if
the database is regenerated -- tests/test_audit_fixes.py re-checks the joins):
  - every session has a campaign_id that exists in marketing_campaigns;
  - customers.region and sessions.geo_ip_region differ in 99% of sessions;
  - email_open_rate ~11% NULL, age 5% NULL, sessions.pages_viewed 5% NULL;
  - age, session_duration and pages_viewed are stored as REAL.
  - the IDs listed as logical keys below are currently unique and all checked
    customer/campaign references resolve, but this SQLite file declares no
    PRIMARY KEY or FOREIGN KEY constraints. Treat them as verified data facts,
    not as database-enforced constraints.
"""

SCHEMA_DESCRIPTION = """
Tables and columns (SQLite):

customers (
  customer_id INTEGER, age REAL, country_code TEXT,
  region TEXT, signup_date TEXT, loyalty_score REAL,
  email_open_rate REAL, discount_usage_rate REAL, avg_review_score REAL,
  referral_code TEXT, customer_tier TEXT, credit_limit REAL
)

sessions (
  session_id INTEGER, customer_id INTEGER,
  session_timestamp TEXT, session_duration REAL, pages_viewed REAL,
  cart_additions INTEGER, bounce_flag INTEGER, traffic_source TEXT,
  device_type TEXT, campaign_id INTEGER, geo_ip_region TEXT
)

transactions (
  transaction_id INTEGER, customer_id INTEGER,
  transaction_timestamp TEXT, order_value REAL, items_count INTEGER,
  payment_method TEXT, discount_applied INTEGER, shipping_speed TEXT,
  high_value_flag TEXT
)

geo_data (
  geo_ip_region TEXT, average_income REAL, urban_ratio REAL,
  internet_penetration REAL, region_tier TEXT
)

marketing_campaigns (
  campaign_id INTEGER, campaign_type TEXT,
  campaign_budget REAL, region_target TEXT, start_date TEXT, end_date TEXT
)

Relationships (no NULL or dangling keys on any of these, so a plain JOIN is safe):
  sessions.customer_id     -> customers.customer_id
  transactions.customer_id -> customers.customer_id
  sessions.campaign_id     -> marketing_campaigns.campaign_id  (every session has a campaign)
  customers.region         -> geo_data.geo_ip_region           (the customer's HOME region)
  sessions.geo_ip_region   -> geo_data.geo_ip_region           (where that one SESSION came from)

Table grain and logical keys:
  customers: one row per customer; customer_id is unique in the supplied data.
  transactions: one row per order; transaction_id is unique.
  sessions: one row per session; session_id is unique.
  marketing_campaigns: one row per campaign; campaign_id is unique.
  geo_data: one row per region; geo_ip_region is unique.
These uniqueness facts were checked against the supplied database. Do not claim
the file enforces them with constraints. Qualify every selected/filter/grouped
column consistently with its table alias (e.g. FROM customers AS c means use
c.email_open_rate, never customers.email_open_rate in that query).
""".strip()

VALID_VALUES_TEXT = """
Valid values for text columns. SQLite text comparison is CASE-SENSITIVE,
so use EXACTLY this spelling:
- customers.country_code: 'US', 'UK', 'DE', 'FR', 'IN'
  (United States/USA/America -> 'US', United Kingdom/Britain -> 'UK',
   Germany -> 'DE', France -> 'FR', India -> 'IN')
- customers.customer_tier: 'Bronze', 'Silver', 'Gold', 'Platinum'
- sessions.traffic_source: 'organic', 'ads', 'social', 'email'
- sessions.device_type: 'desktop', 'mobile', 'tablet'
- transactions.payment_method: 'debit_card', 'credit_card', 'paypal', 'crypto'
- transactions.shipping_speed: 'standard', 'express', 'overnight'
- transactions.high_value_flag: 'Yes', 'No'
- marketing_campaigns.campaign_type: 'Affiliate', 'Email', 'Search', 'Display', 'Social'
- geo_data.region_tier: 'Tier1', 'Tier2', 'Tier3'
- customers.region, sessions.geo_ip_region, geo_data.geo_ip_region,
  marketing_campaigns.region_target: 'region_0' ... 'region_99' -- REGION
  codes, NOT countries.
- All dates/timestamps are 'YYYY-MM-DD' text (no time part).
""".strip()

METRICS_GLOSSARY = """
Orders (transactions):
- revenue = SUM(transactions.order_value)
- orders = COUNT(transactions.transaction_id)
- average order value (AOV) = revenue / orders; an empty filtered set has no AOV (NULL)
- discount usage rate (of orders) = AVG(CASE WHEN transactions.discount_applied THEN 1.0 ELSE 0.0 END)
- high-value order share = AVG(CASE WHEN transactions.high_value_flag = 'Yes' THEN 1.0 ELSE 0.0 END)
- items per order = AVG(transactions.items_count)
Sessions (sessions):
- sessions = COUNT(sessions.session_id)
- bounce rate = AVG(CASE WHEN sessions.bounce_flag THEN 1.0 ELSE 0.0 END)
- session duration / pages per session / cart additions per session = AVG of session_duration / pages_viewed / cart_additions
Customers (one row each, so AVG the column):
- customer count = COUNT(DISTINCT customers.customer_id); new customers = COUNT(*) filtered on signup_date
- email open rate ("opens emails", email engagement) = AVG(customers.email_open_rate), 0 to 1
- loyalty score = AVG(customers.loyalty_score), 0 to 1
- review score / rating = AVG(customers.avg_review_score)
- credit limit = AVG(customers.credit_limit) (SUM only for "total credit")
- customer age = AVG(customers.age)
- customers.discount_usage_rate is a per-customer attribute, NOT the order-level rate above (~0.33 vs ~0.50): use AVG(customers.discount_usage_rate) only when asked about customers' own discount usage.
Geo (geo_data, one row per region): average_income is currency; urban_ratio and internet_penetration are fractions from 0 to 1. For a region-level average, aggregate geo_data directly. When comparing customer tiers by home region, join customers.region = geo_data.geo_ip_region and use AVG(g.internet_penetration); this is customer-weighted because each customer's home region contributes once per customer. State this weighting in the answer. For a distinct-region average, aggregate geo_data before joining or query geo_data directly.
Campaigns (marketing_campaigns): campaigns = COUNT(*); campaign budget = SUM(campaign_budget) from marketing_campaigns ALONE -- joining sessions first multiplies each budget by its session count.

FROM / GROUP BY: the table a metric lives on decides FROM; JOIN only to reach the grouping column.
- customer metrics by country_code / customer_tier / region: customers only.
- order metrics by country / tier / region: transactions JOIN customers; by payment_method / shipping_speed / month: transactions only.
- session metrics by traffic_source / device_type / geo_ip_region: sessions only; by campaign_type: JOIN marketing_campaigns; by country / tier / customer region: JOIN customers.
- geo metrics by region_tier: geo_data only.
""".strip()

COMMON_MISTAKES = """
Common mistakes to avoid:
1. traffic_source / channel exists ONLY on sessions. Never filter a
   revenue/order/AOV query by it.
2. Country lives ONLY in customers.country_code. sessions and
   transactions have no country column: JOIN customers ON customer_id.
3. "purchase" / "order" / "sale" means one row in transactions.
   COUNT(*) on transactions -- NOT SUM(items_count), NOT a customers
   column. To count purchases per customer, JOIN customers with
   transactions and GROUP BY customer_id.
4. "sales" / "how many sales" = NUMBER OF ORDERS (COUNT(*) on
   transactions), not SUM(order_value). Only SUM(order_value) when the
   question says revenue / amount / money / value.
5. "india and us" -> col IN ('IN','US'), NEVER col = 'IN' AND col = 'US'.
   Add GROUP BY that column so each value gets its own row.
6. Never compare a country to sessions.geo_ip_region -- those are region
   codes like 'region_74'.
7. Write literal values directly in the SQL. No parameter placeholders.
8. Always include a LIMIT <= 200, unless the query returns one row.
9. Two region columns disagree in 99% of sessions. customers.region = the
   customer's HOME region: use it for customer metrics (email open rate,
   loyalty, reviews, credit, age) and for revenue / orders by region (JOIN
   customers). sessions.geo_ip_region = where one SESSION came from: use it
   only for session metrics by region (sessions, bounce, device, traffic) or
   when the question says "geo ip". Join geo_data on customers.region for
   customer / order data, on sessions.geo_ip_region for session data.
10. email_open_rate (11% NULL), age and pages_viewed (5% NULL): AVG / MIN /
   MAX skip NULLs, but when ranking rows by one of them add `col IS NOT NULL`
   -- SQLite sorts NULL first in ASC, so "lowest" would return NULL rows.
11. "email" is ambiguous: traffic_source = 'email' is a channel;
   marketing_campaigns.campaign_type = 'Email' is a campaign type (JOIN on
   campaign_id). "email campaign" -> campaign_type; "email traffic / channel"
   -> traffic_source. The two are independent.
12. For "above the average" or "top N per group" use a subquery: WHERE x >
   (SELECT AVG(...) ...), or FROM (SELECT ..., ROW_NUMBER() OVER (PARTITION
   BY ... ORDER BY ...) AS rn ...) AS alias WHERE rn <= N. Always alias a
   derived table.
13. "Above-average customer spend" compares each customer's SUM(order_value)
    with the average of per-customer totals across ALL customers. Start from
    customers LEFT JOIN transactions and COALESCE missing totals to 0, so
    customers with no orders are included in the benchmark. Do NOT compare it
    with AVG(order_value), which is the average single order.
14. A customer attribute grouped by sessions.device_type must first build
    DISTINCT (customer_id, device_type) pairs from sessions, then join those
    pairs to customers. This counts each customer once per device, regardless
    of how many sessions they had on that device.
15. When the question prompt gives an exact relative-date range, use those
    exact inclusive/exclusive bounds on transactions.transaction_timestamp.
    Do not guess a different year. Do not apply transaction dates to customer
    attributes that have no date column.
16. Alias rule: when a table has an alias, use ONLY that alias to qualify its
    columns. Example: `FROM customers AS c` requires `c.email_open_rate` and
    `c.customer_tier`; `customers.email_open_rate` is invalid after aliasing.
    Use short explicit aliases consistently: c=customers, t=transactions,
    s=sessions, g=geo_data, m=marketing_campaigns. Qualify columns in SELECT,
    JOIN, WHERE, GROUP BY, HAVING and ORDER BY where ambiguity is possible.
17. Preserve the metric's grain. Never join raw transactions and raw sessions
    together before aggregating: both are one-to-many from customers and the
    join multiplies rows. Aggregate each fact table to the required grain first.
18. `internet_penetration` and `email_open_rate` are both fractions. Their
    absolute difference multiplied by 100 is a percentage-point gap; label it
    `gap_pp` and display it as percentage points, not as a bare 0.43.
19. Signup-cohort revenue for the first 90 days is a per-customer total:
    LEFT JOIN transactions to customers using transaction_timestamp >=
    signup_date and transaction_timestamp < date(signup_date, '+90 days'),
    sum each customer's order_value, include zero-order customers as 0, then
    average those customer totals by cohort. SQLite does not support
    `INTERVAL '90 days'` syntax.
20. Customer `discount_usage_rate` and order-level discount share are different
    metrics. For the latter, calculate AVG(CASE WHEN discount_applied = 1 THEN
    1.0 ELSE 0.0 END) per customer across ALL of that customer's orders first;
    then average those customer shares by tier. Never keep only discounted
    rows, and never divide a row-level average by COUNT(*).
21. For campaign budget plus attributed sessions, aggregate sessions to one
    row per campaign_id before joining marketing_campaigns. Sum each campaign
    budget once and sum the pre-aggregated session counts separately.
22. For every query with JOINs, qualify columns with their table alias wherever
    possible, especially repeated names such as customer_id and country_code.
    When a CTE needs a grouping key later, SELECT it into the CTE and carry it
    forward; do not re-join the base table just to recover that key.
23. Keep every requested output dimension in the final result and in the
    aggregation grain. A filter such as country_code IN ('IN','US') selects
    both countries; it does NOT create separate country results. If the user
    asks to compare payment methods across countries, SELECT and GROUP BY both
    country_code and payment_method. Before finalizing, compare the requested
    dimensions against the final SELECT and GROUP BY (or window PARTITION BY).
24. Check JOIN cardinality for every measure, not just whether the SQL runs.
    A one-to-many join repeats columns from the one-side. Never SUM a
    campaign-level budget after joining raw sessions: aggregate sessions to
    one row per campaign first, then add those counts to budgets summed once
    per campaign. COUNT(DISTINCT session_id) does not protect a neighboring
    SUM(campaign_budget) from fan-out.
25. When reporting a customer-level attribute by a session dimension (for
    example AVG(customers.email_open_rate) by sessions.device_type), first
    deduplicate sessions to one row per (customer_id, device_type), then join
    customers. Averaging after joining raw sessions weights customers with
    more sessions more heavily and changes the requested customer-level
    average. Use raw session rows only when the requested metric is itself
    session-weighted.
26. Before approving SQL, inspect each measure's source table and grain, the
    grain after every JOIN, and the final aggregation grain. Distinct counts
    may fix duplication for that one count only; they do not fix duplicated
    SUMs or averages elsewhere in the same SELECT.
""".strip()

# Stage 5 whitelist.
ALLOWED_TABLES: dict[str, set[str]] = {
    "customers": {
        "customer_id", "age", "country_code", "region", "signup_date",
        "loyalty_score", "email_open_rate", "discount_usage_rate",
        "avg_review_score", "referral_code", "customer_tier", "credit_limit",
    },
    "sessions": {
        "session_id", "customer_id", "session_timestamp", "session_duration",
        "pages_viewed", "cart_additions", "bounce_flag", "traffic_source",
        "device_type", "campaign_id", "geo_ip_region",
    },
    "transactions": {
        "transaction_id", "customer_id", "transaction_timestamp", "order_value",
        "items_count", "payment_method", "discount_applied", "shipping_speed",
        "high_value_flag",
    },
    "geo_data": {
        "geo_ip_region", "average_income", "urban_ratio",
        "internet_penetration", "region_tier",
    },
    "marketing_campaigns": {
        "campaign_id", "campaign_type", "campaign_budget", "region_target",
        "start_date", "end_date",
    },
}
